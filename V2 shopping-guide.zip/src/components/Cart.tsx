import React from 'react';
import { Minus, Plus, Trash2, ArrowRight, Truck, Store, Info, ShoppingCart } from 'lucide-react';
import { ViewState, CartItem, Product } from '../types';
import { PRODUCTS } from '../data';
import { motion, AnimatePresence } from 'motion/react';

interface CartProps {
  cartItems: CartItem[];
  setCartItems: React.Dispatch<React.SetStateAction<CartItem[]>>;
  setView: (view: ViewState) => void;
}

export const Cart: React.FC<CartProps> = ({ cartItems, setCartItems, setView }) => {
  const updateQuantity = (productId: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.productId === productId) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const removeItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.productId !== productId));
  };

  const getProduct = (id: string) => PRODUCTS.find(p => p.id === id);

  const subtotal = cartItems.reduce((acc, item) => {
    const p = getProduct(item.productId);
    return acc + (p?.price || 0) * item.quantity;
  }, 0);

  return (
    <div className="bg-[#f5f5f5] min-h-screen pb-40">
      {/* Header */}
      <div className="bg-white p-4 sticky top-0 z-10 border-b border-gray-100 flex items-center justify-between">
        <h2 className="text-xl font-bold">購物車</h2>
        <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{cartItems.length} 個項目</span>
      </div>

      <div className="p-4 space-y-4">
        {/* Assistant Tip */}
        <div className="bg-gray-900 border border-gray-800 p-5 rounded-2xl flex gap-4 shadow-xl shadow-gray-200">
          <Info size={24} className="text-gray-400 flex-shrink-0" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-white mb-1 tracking-wide">
              Nest & Co. 智能購物提醒
            </h4>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              我們已為您預估了最快的送貨時間，確認無誤後即可進入安全結帳程序。
            </p>
          </div>
        </div>

        {/* Cart Items */}
        <AnimatePresence initial={false}>
          {cartItems.map((item) => {
            const p = getProduct(item.productId);
            if (!p) return null;
            return (
              <motion.div 
                key={item.productId}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, x: -50 }}
                className="bg-white rounded-xl p-4 flex gap-4 shadow-sm"
              >
                <div className="w-24 h-24 bg-gray-50 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover mix-blend-multiply" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold text-sm truncate pr-2">{p.name}</h3>
                    <button 
                      onClick={() => removeItem(item.productId)}
                      className="text-gray-300 hover:text-red-500"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mb-4">{p.sizeDisplay}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 bg-gray-100 rounded-full px-1">
                      <button 
                        onClick={() => updateQuantity(item.productId, -1)}
                        className="w-8 h-8 flex items-center justify-center text-gray-600"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.productId, 1)}
                        className="w-8 h-8 flex items-center justify-center text-gray-600"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    <span className="font-black text-sm">NT$ {(p.price * item.quantity).toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {cartItems.length === 0 && (
          <div className="py-20 text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mb-4">
              <ShoppingCart size={32} className="text-gray-400" />
            </div>
            <p className="text-gray-400 font-medium mb-6">購物車是空的</p>
            <button 
              onClick={() => setView({ type: 'HOME' })}
              className="bg-[#0058ab] text-white px-8 py-3 rounded-full font-bold"
            >
              去逛逛商品
            </button>
          </div>
        )}

        {/* Delivery Options Summary */}
        {cartItems.length > 0 && (
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <h4 className="font-bold text-sm mb-4">配送資訊摘要</h4>
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-[#0058ab]">
                  <Truck size={20} />
                </div>
                <div>
                  <h5 className="text-xs font-bold">送貨到府</h5>
                  <p className="text-[10px] text-gray-500">預計 3-5 個工作天</p>
                </div>
              </div>
              <span className="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-bold">建議</span>
            </div>
            <div className="flex items-center justify-between opacity-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center text-gray-400">
                  <Store size={20} />
                </div>
                <div>
                  <h5 className="text-xs font-bold">門市取貨</h5>
                  <p className="text-[10px] text-gray-500">請確認門市庫存</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recommendations */}
        <div className="py-4">
          <h4 className="font-bold text-sm mb-4">你可能會感興趣</h4>
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
            {PRODUCTS.slice(2, 4).map(p => (
              <div key={p.id} className="w-32 flex-shrink-0 bg-white p-3 rounded-xl shadow-sm">
                <img src={p.image} alt={p.name} className="w-full aspect-square object-cover mix-blend-multiply mb-2" />
                <h5 className="text-[10px] font-bold truncate mb-1">{p.name}</h5>
                <p className="text-[10px] font-black text-[#0058ab]">NT$ {p.price.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

        {/* Summary Bottom */}
      {cartItems.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 pb-28 z-20 shadow-[0_-10px_30px_rgba(0,0,0,0.04)]">
          <div className="flex justify-between items-center mb-6">
            <div className="flex flex-col">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">總計金額</span>
              <span className="text-2xl font-black text-gray-900">NT$ {subtotal.toLocaleString()}</span>
            </div>
            <button 
              onClick={() => setView({ type: 'CHECKOUT' })}
              className="bg-gray-900 text-white px-8 py-4 rounded-xl font-bold flex items-center gap-2 shadow-xl shadow-gray-200 active:scale-[0.98] transition-transform"
            >
              前往結帳
              <ArrowRight size={20} />
            </button>
          </div>
          <p className="text-center text-[10px] text-gray-400 font-medium tracking-tight">
            滿 NT$ 15,000 即可享尊榮免運服務
          </p>
        </div>
      )}
    </div>
  );
};

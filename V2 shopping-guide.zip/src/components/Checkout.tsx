import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Truck, Store, CreditCard, ChevronRight, Info, ShieldCheck } from 'lucide-react';
import { ViewState, CartItem, Product } from '../types';
import { PRODUCTS } from '../data';
import { motion } from 'motion/react';

interface CheckoutProps {
  cartItems: CartItem[];
  setView: (view: ViewState) => void;
  setCartItems: (items: CartItem[]) => void;
}

export const Checkout: React.FC<CheckoutProps> = ({ cartItems, setView, setCartItems }) => {
  const [deliveryMethod, setDeliveryMethod] = useState<'HOME' | 'STORE'>('HOME');
  const [isSuccess, setIsSuccess] = useState(false);

  const getProduct = (id: string) => PRODUCTS.find(p => p.id === id);
  
  const subtotal = cartItems.reduce((acc, item) => {
    const p = getProduct(item.productId);
    return acc + (p?.price || 0) * item.quantity;
  }, 0);

  const shippingFee = deliveryMethod === 'HOME' ? 500 : 0;
  const total = subtotal + shippingFee;

  const handleOrder = () => {
    setIsSuccess(true);
    setTimeout(() => {
      setCartItems([]);
      setView({ type: 'HOME' });
    }, 2500);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center text-green-500 mb-6"
        >
          <CheckCircle2 size={64} />
        </motion.div>
        <h2 className="text-2xl font-black mb-2">訂單已完成！</h2>
        <p className="text-gray-500 text-sm mb-8">感謝您的購買，我們將盡速為您處理。導向回首頁中...</p>
      </div>
    );
  }

  return (
    <div className="bg-[#f5f5f5] min-h-screen pb-40">
      {/* Header */}
      <div className="bg-white p-4 sticky top-0 z-10 border-b border-gray-100 flex items-center gap-4">
        <button onClick={() => setView({ type: 'CART' })} className="p-1">
          <ArrowLeft size={24} />
        </button>
        <h2 className="text-xl font-bold">結帳</h2>
      </div>

      <div className="p-4 space-y-4">
        {/* Progress Bar */}
        <div className="bg-white p-6 rounded-xl shadow-sm mb-4">
          <div className="flex justify-between items-center mb-2">
            {['資訊', '送貨', '付款'].map((step, idx) => (
              <div key={step} className="flex flex-col items-center flex-1">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold mb-1 ${
                  idx <= 1 ? 'bg-[#0058ab] text-white' : 'bg-gray-200 text-gray-400'
                }`}>
                  {idx + 1}
                </div>
                <span className={`text-[10px] font-bold ${idx <= 1 ? 'text-[#0058ab]' : 'text-gray-400'}`}>
                  {step}
                </span>
              </div>
            ))}
          </div>
          <div className="h-1 bg-gray-100 rounded-full relative">
            <div className="absolute h-full bg-[#0058ab] rounded-full w-1/2" />
          </div>
        </div>

        {/* Step 1: Address */}
        <section className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">收件資訊</h3>
            <button className="text-xs text-[#0058ab] font-bold">修改</button>
          </div>
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center text-gray-400">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <p className="text-sm font-bold mb-1">王大明</p>
              <p className="text-xs text-gray-500 leading-relaxed">
                台北市內湖區新湖一路 168 號 (內湖店旁)<br />
                0912-345-678
              </p>
            </div>
          </div>
        </section>

        {/* Step 2: Delivery Method (Crucial Step 4) */}
        <section className="bg-white rounded-2xl p-6 shadow-sm border border-gray-50">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-6">選擇配送方式</h3>
          <div className="space-y-4">
            <button 
              onClick={() => setDeliveryMethod('HOME')}
              className={`w-full p-4 rounded-xl border-2 flex items-center justify-between transition-all ${
                deliveryMethod === 'HOME' ? 'border-gray-900 bg-gray-50/50 shadow-md translate-y-[-2px]' : 'border-gray-100 grow'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${deliveryMethod === 'HOME' ? 'text-gray-900' : 'text-gray-300'}`}>
                  <Truck size={24} />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-bold">送貨到府</h4>
                  <p className="text-[10px] text-gray-400">最快 1-3 個工作天送達</p>
                </div>
              </div>
              <span className="text-sm font-bold text-gray-900">NT$ 500</span>
            </button>
            <button 
              onClick={() => setDeliveryMethod('STORE')}
              className={`w-full p-4 rounded-xl border-2 flex items-center justify-between transition-all ${
                deliveryMethod === 'STORE' ? 'border-gray-900 bg-gray-50/50 shadow-md translate-y-[-2px]' : 'border-gray-100'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${deliveryMethod === 'STORE' ? 'text-gray-900' : 'text-gray-300'}`}>
                  <Store size={24} />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-bold">門市自取</h4>
                  <p className="text-[10px] text-gray-400">內湖店 (免費)</p>
                </div>
              </div>
              <span className="text-sm font-bold text-gray-900">免費</span>
            </button>
          </div>
        </section>

        {/* Order Summary */}
        <section className="bg-white rounded-2xl p-8 shadow-sm border border-gray-50">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-6">訂單摘要</h3>
          <div className="space-y-4 mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400 font-medium tracking-tight">商品小計 ({cartItems.length} 項)</span>
              <span className="font-bold text-gray-900">NT$ {subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400 font-medium tracking-tight">運費服務</span>
              <span className="font-bold text-green-600">
                {shippingFee === 0 ? '免費' : `NT$ ${shippingFee.toLocaleString()}`}
              </span>
            </div>
            <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
              <span className="font-bold text-gray-900">應付總額</span>
              <span className="text-2xl font-black text-gray-900">NT$ {total.toLocaleString()}</span>
            </div>
          </div>
          
          <div className="bg-gray-100 p-4 rounded-xl flex gap-3 text-[10px] text-gray-400 leading-relaxed italic">
            <Info size={14} className="flex-shrink-0" />
            點擊「確認結帳」即表示您同意 Nest & Co. 的服務條款。我們的物流夥伴將在配送前電話聯絡您。
          </div>
        </section>
      </div>

      {/* Final CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 pb-24 z-20 shadow-[0_-10px_30px_rgba(0,0,0,0.04)]">
        <button 
          onClick={handleOrder}
          disabled={cartItems.length === 0}
          className="w-full bg-gray-900 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-2xl shadow-gray-300 active:scale-[0.98] transition-transform disabled:opacity-50"
        >
          <ShieldCheck size={20} />
          安全付款，完成訂單
        </button>
      </div>
    </div>
  );
};

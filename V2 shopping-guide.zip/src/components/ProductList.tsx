import React, { useState, useMemo } from 'react';
import { ArrowLeft, SlidersHorizontal, ChevronDown, ShoppingCart, Info } from 'lucide-react';
import { ViewState, Product, Category } from '../types';
import { PRODUCTS, CATEGORIES } from '../data';
import { motion, AnimatePresence } from 'motion/react';

interface ProductListProps {
  categoryId: string;
  setView: (view: ViewState) => void;
  addToCart: (productId: string) => void;
  aiSummary?: string;
  initialFilters?: {
    minPrice?: number;
    maxPrice?: number;
    keywords?: string[];
  };
}

export const ProductList: React.FC<ProductListProps> = ({ 
  categoryId, 
  setView, 
  addToCart, 
  aiSummary, 
  initialFilters 
}) => {
  const category = CATEGORIES.find(c => c.id === categoryId);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [maxPrice, setMaxPrice] = useState<number>(initialFilters?.maxPrice || 15000);

  const products = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchCategory = p.categoryId === categoryId;
      const matchSize = !selectedSize || p.sizeDisplay === selectedSize;
      const matchPrice = p.price <= maxPrice;
      
      // AI keyword matching (simplified)
      let matchKeywords = true;
      if (initialFilters?.keywords) {
        matchKeywords = initialFilters.keywords.some(k => 
          p.name.toLowerCase().includes(k.toLowerCase()) || 
          p.description.toLowerCase().includes(k.toLowerCase()) ||
          p.tags.some(t => t.toLowerCase().includes(k.toLowerCase()))
        );
      }
      
      return matchCategory && matchSize && matchPrice && matchKeywords;
    });
  }, [categoryId, selectedSize, maxPrice, initialFilters]);

  const sizes = categoryId === 'mattress' ? ['單人', '雙人', '雙人加大'] : ['小', '中', '大'];

  return (
    <div className="bg-white min-h-screen pb-24">
      {/* List Header */}
      <div className="sticky top-0 bg-white z-10">
        <div className="p-4 flex items-center gap-4">
          <button onClick={() => setView({ type: 'HOME' })} className="p-1">
            <ArrowLeft size={24} />
          </button>
          <div className="flex-1">
            <h2 className="text-xl font-bold">{category?.name}</h2>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest px-0.5">
              {products.length} 項商品
            </p>
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-xl border transition-all ${showFilters ? 'bg-gray-900 text-white border-gray-900 shadow-lg' : 'bg-white border-gray-100 text-gray-400'}`}
          >
            <SlidersHorizontal size={20} />
          </button>
        </div>

        {/* Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="px-4 overflow-hidden border-b border-gray-100 pb-6"
            >
              <div className="space-y-6">
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">尺寸規格</h4>
                  <div className="flex flex-wrap gap-2">
                    {sizes.map(s => (
                      <button
                        key={s}
                        onClick={() => setSelectedSize(selectedSize === s ? null : s)}
                        className={`px-5 py-2 rounded-lg text-[11px] font-bold border transition-all ${
                          selectedSize === s 
                          ? 'bg-gray-900 text-white border-gray-900 shadow-md' 
                          : 'bg-white text-gray-400 border-gray-100'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-end mb-3">
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">預算上限</h4>
                    <span className="text-xs font-black text-gray-900 font-mono">NT$ {maxPrice.toLocaleString()}</span>
                  </div>
                  <input 
                    type="range" 
                    min="500" 
                    max="20000" 
                    step="500"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                    className="w-full h-1 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-gray-900"
                  />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Guided / AI Message */}
        <div className={`px-6 py-4 flex flex-col gap-2 transition-colors ${aiSummary ? 'bg-gray-900 border-b border-white/5 shadow-2xl' : 'bg-gray-50'}`}>
          <div className="flex items-center gap-3">
            <div className={`p-1 rounded-full ${aiSummary ? 'bg-white/10' : 'bg-gray-200'}`}>
              <Info size={14} className={aiSummary ? 'text-white/60' : 'text-gray-400'} />
            </div>
            <p className={`text-[10px] font-bold tracking-tight ${aiSummary ? 'text-white' : 'text-gray-500'}`}>
              {aiSummary 
                ? `已根據您的需求過濾：${aiSummary}` 
                : (categoryId === 'mattress' 
                    ? 'Nest & Co. 建議您根據軟硬度與睡感進行挑選' 
                    : '完美空間，從選擇合適的尺寸與材質開始')}
            </p>
          </div>
          {aiSummary && (
            <div className="flex flex-wrap gap-2 mt-1">
              {initialFilters?.keywords?.map(k => (
                <span key={k} className="text-[9px] font-black uppercase tracking-widest text-white/60">#{k}</span>
              ))}
              {initialFilters?.maxPrice && (
                <span className="text-[9px] font-black uppercase tracking-widest text-white/60">#預算內</span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Grid */}
      <div className="p-4 grid grid-cols-2 gap-x-3 gap-y-6">
        {products.map((p) => (
          <div key={p.id} className="flex flex-col group">
            <div 
              onClick={() => setView({ type: 'PRODUCT_DETAIL', productId: p.id })}
              className="aspect-square bg-gray-100 rounded-xl mb-3 overflow-hidden relative cursor-pointer border border-gray-100"
            >
              <img src={p.image} alt={p.name} className="w-full h-full object-cover mix-blend-multiply" />
              {p.aiReason && (
                <div className="absolute bottom-2 left-2 right-2">
                  <div className="bg-white/80 backdrop-blur-md px-2 py-1.5 rounded-lg border border-gray-100 shadow-sm">
                    <p className="text-[8px] font-black leading-tight text-gray-900 line-clamp-1">
                      <span className="text-gray-400 mr-1">✦</span>
                      {p.aiReason}
                    </p>
                  </div>
                </div>
              )}
              {p.tags.length > 0 && !p.aiReason && (
                <div className="absolute top-2 left-2 flex flex-col gap-1">
                  {p.tags.map(t => (
                    <span key={t} className="bg-white/90 backdrop-blur-sm text-[8px] font-black px-1.5 py-0.5 rounded shadow-sm">
                      {t}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div className="flex-1 px-1">
              <h3 
                onClick={() => setView({ type: 'PRODUCT_DETAIL', productId: p.id })}
                className="text-[11px] font-black leading-tight mb-0.5 cursor-pointer hover:text-[--color-ikea-blue]"
              >
                {p.name}
              </h3>
              <p className="text-[9px] text-gray-400 mb-2 truncate">{p.description}</p>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-sm font-black text-[--color-ikea-blue]">NT$ {p.price.toLocaleString()}</span>
                <button 
                  onClick={() => addToCart(p.id)}
                  className="bg-[--color-ikea-yellow] text-gray-900 p-2 rounded-sm shadow-sm active:scale-95 transition-transform"
                >
                  <ShoppingCart size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {products.length === 0 && (
        <div className="p-12 text-center text-gray-400">
          <p>沒有符合條件的商品，試著調整篩選範圍</p>
        </div>
      )}
    </div>
  );
};

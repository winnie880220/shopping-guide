import React, { useState } from 'react';
import { ArrowLeft, Heart, Share2, MapPin, ChevronRight, Check, AlertCircle, ShoppingCart } from 'lucide-react';
import { ViewState, Product } from '../types';
import { PRODUCTS } from '../data';
import { motion } from 'motion/react';

interface ProductDetailProps {
  productId: string;
  setView: (view: ViewState) => void;
  addToCart: (productId: string) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ productId, setView, addToCart }) => {
  const product = PRODUCTS.find(p => p.id === productId);
  const [selectedStock, setSelectedStock] = useState<string>('內湖店');

  if (!product) return null;

  const currentStock = product.stock.find(s => s.location === selectedStock) || { status: 'out-of-stock' };

  return (
    <div className="bg-white min-h-screen pb-32">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10 pointer-events-none">
        <button 
          onClick={() => setView({ type: 'HOME' })} 
          className="p-2 bg-white rounded-full shadow-lg pointer-events-auto active:scale-90"
        >
          <ArrowLeft size={20} />
        </button>
        <div className="flex gap-2 pointer-events-auto">
          <button className="p-2 bg-white rounded-full shadow-lg border border-gray-100">
            <Share2 size={18} />
          </button>
          <button className="p-2 bg-white rounded-full shadow-lg border border-gray-100 text-red-500">
            <Heart size={18} />
          </button>
        </div>
      </div>

      {/* Main Image */}
      <div className="bg-gray-100 aspect-square overflow-hidden mb-6 border-b border-gray-50">
        <motion.img 
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover mix-blend-multiply" 
        />
      </div>

      <div className="px-6">
        <div className="mb-6">
          <h2 className="text-xl font-black mb-0.5">{product.name}</h2>
          <p className="text-gray-400 text-[10px] italic mb-3">{product.description}</p>
          <span className="text-2xl font-black text-[--color-ikea-blue]">NT$ {product.price.toLocaleString()}</span>
        </div>

        {/* Guided Recommendations */}
        <section className="mb-8 nest-card p-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 flex items-center gap-2">
            <Check size={14} className="text-green-500" />
            推薦理由
          </h3>
          <ul className="space-y-3">
            {product.details.map((detail, idx) => (
              <li key={idx} className="text-[10px] text-gray-600 flex items-start gap-2 leading-relaxed">
                <div className="mt-1 w-1.5 h-1.5 bg-gray-200 rounded-full flex-shrink-0" />
                {detail}
              </li>
            ))}
          </ul>
        </section>

        {/* Inventory Status */}
        <section className="mb-8">
          <div className="flex justify-between items-center mb-4 px-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">分店庫存</h3>
            <div className="flex items-center gap-1 text-[10px] font-bold text-gray-900">
              <MapPin size={12} />
              切換地點
            </div>
          </div>
          <div className="nest-card p-5">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="font-bold text-sm mb-1">{selectedStock}：現貨供應</h4>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${currentStock.status === 'out-of-stock' ? 'bg-red-500' : 'bg-green-500'}`} />
                  <span className={`text-[10px] font-bold ${currentStock.status === 'out-of-stock' ? 'text-red-500' : 'text-green-600'}`}>
                    {currentStock.status === 'out-of-stock' ? '目前無庫存' : '庫存充足'}
                  </span>
                </div>
              </div>
              <ChevronRight size={18} className="text-gray-300" />
            </div>
            <div className="mt-3 pt-3 border-t border-gray-50">
              <p className="text-[10px] text-gray-400">放置區域: 貨架 12, 走道 04</p>
            </div>
          </div>
        </section>

        {/* Extra Buttons */}
        <div className="mb-8 flex flex-col gap-2">
          <button className="nest-btn-secondary px-6">查看產品規格與尺寸</button>
          <button className="nest-btn-secondary px-6">查看評價與搭配建議</button>
        </div>
      </div>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-5 pb-12 flex gap-3 z-20 shadow-[0_-5px_15px_rgba(0,0,0,0.03)]">
        <button className="p-4 border border-gray-100 rounded-sm text-gray-400 active:scale-95 transition-all">
          <Heart size={20} />
        </button>
        <button 
          onClick={() => {
            addToCart(product.id);
            setView({ type: 'CART' });
          }}
          className="nest-btn-primary flex-1 !text-[13px] !py-4 shadow-lg shadow-gray-200"
        >
          加入購物車
        </button>
      </div>
    </div>
  );
};

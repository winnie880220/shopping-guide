import React, { useState } from 'react';
import { Search as SearchIcon, X, ArrowLeft, History, TrendingUp, SlidersHorizontal, ChevronRight } from 'lucide-react';
import { ViewState } from '../types';
import { CATEGORIES } from '../data';
import { motion, AnimatePresence } from 'motion/react';

interface SearchProps {
  setView: (view: ViewState) => void;
  initialQuery?: string;
}

export const Search: React.FC<SearchProps> = ({ setView, initialQuery = '' }) => {
  const [query, setQuery] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/parse-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q }),
      });
      
      const data = await response.json();
      
      if (data.categoryId) {
        setView({ 
          type: 'PRODUCT_LIST', 
          categoryId: data.categoryId, 
          filters: data,
          aiSummary: data.aiSummary
        });
      } else {
        // Fallback
        setView({ type: 'PRODUCT_LIST', categoryId: 'mattress' });
      }
    } catch (error) {
      console.error("Search error:", error);
      setView({ type: 'PRODUCT_LIST', categoryId: 'mattress' });
    } finally {
      setIsLoading(false);
    }
  };

  const recentSearches = ['小坪數茶几', '偏硬床墊', '雙人床框'];
  const trendingSearches = ['夏季床單', '收納盒', '落地燈', '戶外家具'];

  return (
    <div className="bg-white min-h-screen pb-24">
      {/* Search Header */}
      <div className="p-4 flex items-center gap-3 border-b border-gray-100">
        <button onClick={() => setView({ type: 'HOME' })} className="p-1">
          <ArrowLeft size={24} />
        </button>
        <form onSubmit={handleSearch} className="flex-1 relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="想找什麼呢？"
            autoFocus
            className="w-full bg-gray-100 rounded-full py-2 pl-10 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900"
          />
          <SearchIcon className="absolute left-3 top-2.5 text-gray-400" size={18} />
          {isLoading ? (
            <div className="absolute right-3 top-2.5">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-4 h-4 border-2 border-gray-900 border-t-transparent rounded-full"
              />
            </div>
          ) : query && (
            <button 
              type="button"
              onClick={() => setQuery('')}
              className="absolute right-3 top-2.5 text-gray-400"
            >
              <X size={18} />
            </button>
          )}
        </form>
      </div>

      <div className="p-4">
        {/* Assistant Tips */}
        {!query && (
          <div className="mb-8 p-6 bg-gray-900 rounded-3xl shadow-xl shadow-gray-200">
            <h4 className="text-[12px] font-black text-white mb-2 uppercase tracking-widest">
              Nest & Co. 尋感助手
            </h4>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              試試搜尋：小坪數茶几、偏硬床墊，我們可以幫您更精準地尋找商品。
            </p>
          </div>
        )}

        {/* Recent & Trending */}
        {!query && (
          <>
            <section className="mb-8">
              <div className="flex items-center gap-2 mb-4 text-gray-400">
                <History size={14} />
                <h3 className="text-xs font-bold uppercase tracking-wider">最近搜尋</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((s) => (
                  <button 
                    key={s}
                    onClick={() => setQuery(s)}
                    className="px-4 py-2 bg-gray-100 rounded-full text-[11px] font-bold text-gray-700"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </section>

            <section className="mb-8">
              <div className="flex items-center gap-2 mb-4 text-gray-400">
                <TrendingUp size={16} />
                <h3 className="text-sm font-bold text-gray-900">熱門關鍵字</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {trendingSearches.map((s) => (
                  <button 
                    key={s}
                    onClick={() => setQuery(s)}
                    className="px-4 py-2 border border-gray-100 rounded-full text-sm text-gray-700"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </section>

            <section>
              <h3 className="text-sm font-bold mb-4">商品分類</h3>
              <div className="space-y-4">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setView({ type: 'PRODUCT_LIST', categoryId: cat.id })}
                    className="w-full flex items-center gap-4 p-2 bg-white rounded-xl active:bg-gray-50"
                  >
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                      <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 text-left">
                      <h4 className="font-bold text-sm">{cat.name}</h4>
                      <p className="text-xs text-gray-500">{cat.description}</p>
                    </div>
                    <ChevronRight size={18} className="text-gray-300" />
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {/* Search Results Preview logic would go here */}
        {query && (
          <div className="mt-4">
            <button 
              onClick={() => {
                if (query === '床墊') setView({ type: 'PRODUCT_LIST', categoryId: 'mattress' });
              }}
              className="w-full text-left p-4 flex items-center justify-between border-b border-gray-50"
            >
              <div className="flex items-center gap-3">
                <SearchIcon size={18} className="text-gray-400" />
                <span className="font-medium">搜尋「{query}」</span>
              </div>
              <ChevronRight size={18} className="text-gray-300" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
